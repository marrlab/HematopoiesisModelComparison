amipath = fileparts(mfilename('fullpath'));
addpath(amipath)
addpath(fullfile(amipath,'auxiliary'))
addpath(fullfile(amipath,'auxiliary','CalcMD5'))
addpath(fullfile(amipath,'symbolic'))
addpath(fullfile(amipath,'SBMLimporter'))