function fun = am_eq(varargin)
% am_eq is currently a placeholder that simply produces an error message
%
% Parameters:
%  varargin: elements for chain of equalities 
%
% Return values:
%  fun: logical value, negative for false, positive for true
error('Logical operator ''eq'' is currently not supported!');
end