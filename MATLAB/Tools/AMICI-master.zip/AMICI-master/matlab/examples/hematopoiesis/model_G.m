

%%
% COMPILATION

[exdir,~,~]=fileparts(which('model_G.m'));
% compile the model
amiwrap('model_G','model_G_syms',exdir)
% add the model to the path
addpath(genpath([strrep(which('amiwrap.m'),'amiwrap.m','') 'models/model_G']))

