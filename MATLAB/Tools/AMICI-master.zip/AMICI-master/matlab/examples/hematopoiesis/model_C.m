

%%
% COMPILATION

[exdir,~,~]=fileparts(which('model_C.m'));
% compile the model
amiwrap('model_C','model_C_syms',exdir)
% add the model to the path
addpath(genpath([strrep(which('amiwrap.m'),'amiwrap.m','') 'models/model_C']))

