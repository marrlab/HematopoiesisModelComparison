
%%
% COMPILATION

[exdir,~,~]=fileparts(which('model_A.m'));
% compile the model
amiwrap('model_A','model_A_syms',exdir)
% add the model to the path
addpath(genpath([strrep(which('amiwrap.m'),'amiwrap.m','') 'models/model_A']))

